//
//  AppDelegate.h
//  projectDemo3
//
//  Created by MacBook Pro on 5/11/18.
//  Copyright © 2018 Mac Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

